// Firestore 保存処理（本番書き込み用）

import { db } from "./index";
import { doc, setDoc, serverTimestamp } from "firebase/firestore";

// 予約データを Firestore に保存
export const saveReservation = async (userId, reservation) => {
  if (!userId) throw new Error("userId がありません");

  const ref = doc(db, "users", userId, "reservations", reservation.id);

  await setDoc(ref, {
    ...reservation,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  });

  return true;
};
