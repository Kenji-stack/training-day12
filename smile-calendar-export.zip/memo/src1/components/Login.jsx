// src/components/Login.jsx
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { auth } from "../firebase";
import { GoogleAuthProvider, signInWithPopup } from "firebase/auth";
import "../styles/login.css";

export default function Login() {
  const [error, setError] = useState("");
  const navigate = useNavigate();

  // -------------------------
  // Google でログイン
  // -------------------------
  const handleGoogleLogin = async () => {
    setError("");
    try {
      const provider = new GoogleAuthProvider();
      await signInWithPopup(auth, provider);

      // ログイン成功 → カレンダー画面へ
      navigate("/calendar");
    } catch (e) {
      console.error("Google login failed:", e);
      setError("ログインに失敗しました。再度お試しください。");
    }
  };

  return (
    <div className="apple-login-page">
      <div className="apple-login-card" role="main" aria-labelledby="login-title">
        
        <h1 id="login-title" className="apple-title">Smile Calendar</h1>
        <p className="apple-sub">予約と通院記録をカンタン管理</p>

        <div className="apple-login-actions">
          <button
            className="apple-btn apple-btn-google"
            onClick={handleGoogleLogin}
            aria-label="Google でログイン"
          >
            {/* Google アイコン */}
            <svg
              className="apple-google-icon"
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 533.5 544.3"
            >
              <path
                fill="#4285F4"
                d="M533.5 278.4c0-17.4-1.4-34.1-4.1-50.4H272v95.6h147.2c-6.4 34.6-25.9 64-55.2 83.6v69.4h89.1c52.2-48.1 82.4-119 82.4-198.2z"
              />
              <path
                fill="#34A853"
                d="M272 544.3c73.9 0 135.9-24.3 181.2-66l-89.1-69.4c-24.8 16.7-56.6 26.6-92.1 26.6-70.8 0-130.8-47.8-152.3-112.1H29.4v70.6C74.6 488.9 167.6 544.3 272 544.3z"
              />
              <path
                fill="#FBBC05"
                d="M119.7 324.4c-10.9-32.7-10.9-68 0-100.7V153.1H29.4c-39.9 79.9-39.9 172.1 0 252l90.3-80.7z"
              />
              <path
                fill="#EA4335"
                d="M272 109.1c39 0 74 13.4 101.6 39.6l76.1-76.1C407.9 25.2 343.5 0 272 0 167.6 0 74.6 55.4 29.4 137.1l90.3 70.3C141.2 156.9 201.2 109.1 272 109.1z"
              />
            </svg>

            <span>Sign in with Google</span>
          </button>
        </div>

        {/* エラー */}
        {error && <div className="apple-error">{error}</div>}

        <footer className="apple-footer">
          <small>By signing in you agree to the Terms of Service.</small>
        </footer>
      </div>
    </div>
  );
}
