// src/components/DayRecord.jsx
import React, { useEffect, useState } from 'react'
import { doc, setDoc, deleteDoc } from "firebase/firestore"
import { db } from "../firebase"
import { useAuth } from "../context/AuthContext"

export default function DayRecord({ dateKey, record }) {
  const { currentUser } = useAuth()

  const [form, setForm] = useState({
    brushingMorning: false,
    brushingNoon: false,
    brushingNight: false,
    mouthwash: false,
    floss: false,
    memo: ''
  })
  const [loading, setLoading] = useState(false)

  // Firestore の record を UI に反映
  useEffect(() => {
    if (record) {
      setForm({
        brushingMorning: !!record.brushingMorning,
        brushingNoon: !!record.brushingNoon,
        brushingNight: !!record.brushingNight,
        mouthwash: !!record.mouthwash,
        floss: !!record.floss,
        memo: record.memo || ''
      })
    } else {
      setForm({
        brushingMorning: false,
        brushingNoon: false,
        brushingNight: false,
        mouthwash: false,
        floss: false,
        memo: ''
      })
    }
  }, [dateKey, record])

  // ------------------------
  // 🔥 Firestore へ保存
  // ------------------------
  const save = async () => {
    if (!currentUser) return alert("ログインが必要です")

    setLoading(true)

    try {
      const ref = doc(db, "users", currentUser.uid, "records", dateKey)

      await setDoc(ref, {
        ...form,
        updatedAt: new Date()
      })

      alert("保存しました")
    } catch (err) {
      console.error("保存エラー:", err)
      alert("保存に失敗しました")
    }

    setLoading(false)
  }

  // ------------------------
  // 🔥 Firestore の削除
  // ------------------------
  const remove = async () => {
    if (!currentUser) return alert("ログインが必要です")
    if (!window.confirm("本当に削除しますか？")) return

    setLoading(true)

    try {
      const ref = doc(db, "users", currentUser.uid, "records", dateKey)
      await deleteDoc(ref)
      alert("削除しました")
    } catch (err) {
      console.error("削除エラー:", err)
      alert("削除に失敗しました")
    }

    setLoading(false)
  }

  return (
    <div className="p-4 border rounded">
      <h2 className="text-lg font-medium mb-2">{dateKey}</h2>

      <div className="grid gap-2">

        {/* 朝 */}
        <label className="inline-flex items-center">
          <input
            type="checkbox"
            className="mr-2"
            checked={form.brushingMorning}
            onChange={(e) =>
              setForm({ ...form, brushingMorning: e.target.checked })
            }
          />
          朝の歯みがき
        </label>

        {/* 昼 */}
        <label className="inline-flex items-center">
          <input
            type="checkbox"
            className="mr-2"
            checked={form.brushingNoon}
            onChange={(e) =>
              setForm({ ...form, brushingNoon: e.target.checked })
            }
          />
          昼の歯みがき
        </label>

        {/* 夜 */}
        <label className="inline-flex items-center">
          <input
            type="checkbox"
            className="mr-2"
            checked={form.brushingNight}
            onChange={(e) =>
              setForm({ ...form, brushingNight: e.target.checked })
            }
          />
          夜の歯みがき
        </label>

        {/* マウスウォッシュ */}
        <label className="inline-flex items-center">
          <input
            type="checkbox"
            className="mr-2"
            checked={form.mouthwash}
            onChange={(e) =>
              setForm({ ...form, mouthwash: e.target.checked })
            }
          />
          マウスウォッシュ
        </label>

        {/* フロス */}
        <label className="inline-flex items-center">
          <input
            type="checkbox"
            className="mr-2"
            checked={form.floss}
            onChange={(e) =>
              setForm({ ...form, floss: e.target.checked })
            }
          />
          フロス
        </label>

        {/* メモ */}
        <textarea
          className="border p-2 rounded"
          rows={3}
          value={form.memo}
          onChange={(e) =>
            setForm({ ...form, memo: e.target.value })
          }
          placeholder="通院予約・通院記録・メモ"
        />
      </div>

      <div className="flex gap-2 mt-4">
        <button
          onClick={save}
          disabled={loading}
          className="px-3 py-1 bg-blue-500 text-white rounded disabled:opacity-50"
        >
          保存
        </button>

        <button
          onClick={remove}
          disabled={loading}
          className="px-3 py-1 bg-red-500 text-white rounded disabled:opacity-50"
        >
          削除
        </button>
      </div>
    </div>
  )
}
