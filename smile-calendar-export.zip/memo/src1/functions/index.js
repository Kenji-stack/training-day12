/**
 * Cloud Functions for Firebase - Node.js 22 (2nd Gen)
 */
import { onRequest } from "firebase-functions/v2/https";
import { initializeApp } from "firebase-admin/app";
import { getAuth } from "firebase-admin/auth";
import { getFirestore } from "firebase-admin/firestore";

// Admin SDK 初期化
initializeApp();
const db = getFirestore();

/* -----------------------------------------
   🔹 Token 検証の内部関数（名前を変える）
----------------------------------------- */
async function verifyUserToken(req) {
  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    throw new Error("No token");
  }

  const token = authHeader.replace("Bearer ", "");
  return await getAuth().verifyIdToken(token);
}

/* -----------------------------------------
   🔹 予約作成 API
----------------------------------------- */
export const createReservation = onRequest(async (req, res) => {
  try {
    if (req.method !== "POST") {
      return res.status(405).send("Method Not Allowed");
    }

    const decoded = await verifyUserToken(req);
    const uid = decoded.uid;

    const { title, date } = req.body;

    if (!title || !date) {
      return res.status(400).json({ error: "title or date missing" });
    }

    const docRef = await db.collection("reservations").add({
      uid,
      title,
      date,
      createdAt: new Date(),
    });

    return res.json({ id: docRef.id, result: "ok" });
  } catch (e) {
    console.error("createReservation ERROR:", e);
    return res.status(500).json({ error: String(e) });
  }
});

/* -----------------------------------------
   🔹 予約一覧取得 API
----------------------------------------- */
export const getReservations = onRequest(async (req, res) => {
  try {
    if (req.method !== "GET") {
      return res.status(405).send("Method Not Allowed");
    }

    const decoded = await verifyUserToken(req);
    const uid = decoded.uid;

    const snapshot = await db
      .collection("reservations")
      .where("uid", "==", uid)
      .orderBy("date")
      .get();

    const list = snapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data(),
    }));

    return res.json(list);
  } catch (e) {
    console.error("getReservations ERROR:", e);
    return res.status(500).json({ error: String(e) });
  }
});

/* -----------------------------------------
   🔹 Token 検証 API
----------------------------------------- */
export const verifyToken = onRequest(async (req, res) => {
  try {
    const decoded = await verifyUserToken(req);
    return res.json({ uid: decoded.uid });
  } catch (e) {
    return res.status(401).json({ error: "invalid token" });
  }
});
