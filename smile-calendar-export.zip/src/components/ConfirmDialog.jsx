// src/components/ConfirmDialog.jsx
import React from 'react';

/**
 * カスタム確認ダイアログ
 * IEC 62366-1準拠: window.confirmの代替、より詳細な情報提供
 * FMEA対応: 誤削除リスク(RPN=126)の軽減
 */
export default function ConfirmDialog({
    isOpen,
    title,
    message,
    details,
    confirmText = '確認',
    cancelText = 'キャンセル',
    severity = 'warning', // 'info' | 'warning' | 'danger'
    onConfirm,
    onCancel
}) {
    const severityStyles = {
        info: {
            icon: 'ℹ️',
            confirmBtn: 'bg-blue-500 hover:bg-blue-600 text-white'
        },
        warning: {
            icon: '⚠️',
            confirmBtn: 'bg-yellow-500 hover:bg-yellow-600 text-white'
        },
        danger: {
            icon: '🛑',
            confirmBtn: 'bg-red-500 hover:bg-red-600 text-white'
        }
    };

    const style = severityStyles[severity] || severityStyles.warning;

    // フォーカストラップの処理 - useEffectは常に呼ばれる必要がある
    React.useEffect(() => {
        if (isOpen) {
            const handleEscape = (e) => {
                if (e.key === 'Escape') {
                    onCancel();
                }
            };
            document.addEventListener('keydown', handleEscape);
            return () => document.removeEventListener('keydown', handleEscape);
        }
    }, [isOpen, onCancel]);

    // 早期リターンはuseEffectの後に
    if (!isOpen) return null;

    return (
        <>
            {/* Backdrop */}
            <div
                className="fixed inset-0 bg-black bg-opacity-50 z-40"
                onClick={onCancel}
                aria-hidden="true"
            />

            {/* Dialog */}
            <div
                className="fixed inset-0 flex items-center justify-center z-50 p-4"
                role="dialog"
                aria-modal="true"
                aria-labelledby="dialog-title"
                aria-describedby="dialog-description"
            >
                <div className="bg-white rounded-lg shadow-xl max-w-md w-full p-6 animate-fadeIn">
                    {/* Header */}
                    <div className="flex items-start mb-4">
                        <span className="text-3xl mr-3" aria-hidden="true">
                            {style.icon}
                        </span>
                        <div className="flex-1">
                            <h2 id="dialog-title" className="text-xl font-bold text-gray-900">
                                {title}
                            </h2>
                        </div>
                    </div>

                    {/* Content */}
                    <div id="dialog-description" className="mb-6">
                        <p className="text-gray-700 mb-2 font-medium">
                            {message}
                        </p>
                        {details && (
                            <p className="text-sm text-gray-600 bg-gray-50 border-l-4 border-gray-300 p-3 rounded">
                                {details}
                            </p>
                        )}
                    </div>

                    {/* Actions */}
                    <div className="flex gap-3 justify-end">
                        <button
                            onClick={onCancel}
                            className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50 font-medium transition-colors focus:outline-none focus:ring-2 focus:ring-gray-400"
                            autoFocus={severity !== 'danger'} // 危険な操作でない場合はキャンセルにフォーカス
                        >
                            {cancelText}
                        </button>
                        <button
                            onClick={onConfirm}
                            className={`px-4 py-2 rounded-md font-medium transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 ${style.confirmBtn}`}
                            autoFocus={severity === 'danger'} // 危険な操作の場合は確認ボタンにフォーカス（意図的な選択を促す）
                        >
                            {confirmText}
                        </button>
                    </div>
                </div>
            </div>
        </>
    );
}
