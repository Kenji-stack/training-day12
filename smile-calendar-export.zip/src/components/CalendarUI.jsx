import React from 'react'
import Calendar from 'react-calendar'
import 'react-calendar/dist/Calendar.css'
import { formatDateKey } from '../utils/formatDate'

export default function CalendarUI({ onSelectDate, recordsByDate }) {
  console.log("CalendarUI レンダリング:", { count: recordsByDate ? Object.keys(recordsByDate).length : 0 });

  // 月の画面遷移時に1日を選択
  const handleActiveStartDateChange = ({ activeStartDate, view }) => {
    if (view === 'month' && activeStartDate) {
      // 新しい月の1日を選択
      const firstDay = new Date(activeStartDate.getFullYear(), activeStartDate.getMonth(), 1);
      onSelectDate(formatDateKey(firstDay));
    }
  };

  return (
    <div role="application" aria-label="カレンダー">
      <Calendar
        onClickDay={(d) => onSelectDate(formatDateKey(d))}
        onActiveStartDateChange={handleActiveStartDateChange}
        locale="ja-JP"
        tileContent={({ date }) => {
          const key = formatDateKey(date)
          const record = recordsByDate && recordsByDate[key]
          if (!record) return null

          const icons = []
          if (record.brushingMorning) icons.push('🌅')
          if (record.brushingNoon) icons.push('☀️')
          if (record.brushingNight) icons.push('🌙')
          if (record.mouthwash) icons.push('💧')
          if (record.floss) icons.push('🦷')
          if (record.memo) icons.push('📝')

          return (
            <div style={{
              marginTop: '2px',
              fontSize: '16px',
              display: 'flex',
              justifyContent: 'center',
              gap: '2px'
            }}>
              {icons.map((ic, i) => (
                <span
                  key={i}
                  style={{
                    display: 'inline-block',
                    padding: '1px 2px',
                    backgroundColor: 'rgba(255, 255, 255, 0.8)',
                    borderRadius: '3px'
                  }}
                >
                  {ic}
                </span>
              ))}
            </div>
          )
        }}
      />
    </div>
  )
}
