// src/components/ErrorMessage.jsx
import React from 'react';

/**
 * 再利用可能なエラーメッセージコンポーネント
 * IEC 62366-1準拠: 具体的で行動指向のエラーメッセージを提供
 */
export default function ErrorMessage({
    type = 'error',
    message,
    details,
    action,
    onAction,
    onDismiss
}) {
    const [showDetails, setShowDetails] = React.useState(false);

    const styles = {
        error: {
            bg: 'bg-red-50',
            border: 'border-red-200',
            text: 'text-red-800',
            icon: '❌'
        },
        warning: {
            bg: 'bg-yellow-50',
            border: 'border-yellow-200',
            text: 'text-yellow-800',
            icon: '⚠️'
        },
        success: {
            bg: 'bg-green-50',
            border: 'border-green-200',
            text: 'text-green-800',
            icon: '✅'
        },
        info: {
            bg: 'bg-blue-50',
            border: 'border-blue-200',
            text: 'text-blue-800',
            icon: 'ℹ️'
        }
    };

    const style = styles[type] || styles.error;

    return (
        <div
            className={`${style.bg} ${style.border} ${style.text} border rounded-lg p-3 mb-3`}
            role="alert"
            aria-live="assertive"
            aria-atomic="true"
        >
            <div className="flex items-start">
                <span className="text-xl mr-2" aria-hidden="true">{style.icon}</span>
                <div className="flex-1">
                    <div className="font-medium text-sm">{message}</div>

                    {details && (
                        <div className="mt-2">
                            <button
                                onClick={() => setShowDetails(!showDetails)}
                                className="text-xs underline hover:no-underline focus:outline-none"
                                aria-expanded={showDetails}
                            >
                                {showDetails ? '詳細を隠す' : '詳細を表示'}
                            </button>
                            {showDetails && (
                                <div className="mt-1 text-xs opacity-90">
                                    {details}
                                </div>
                            )}
                        </div>
                    )}

                    {(action || onDismiss) && (
                        <div className="mt-3 flex gap-2">
                            {action && onAction && (
                                <button
                                    onClick={onAction}
                                    className={`${style.text} border ${style.border} hover:bg-opacity-20 px-3 py-1 rounded text-xs font-medium transition-colors`}
                                >
                                    {action}
                                </button>
                            )}
                            {onDismiss && (
                                <button
                                    onClick={onDismiss}
                                    className="text-gray-600 hover:text-gray-800 text-xs underline"
                                >
                                    閉じる
                                </button>
                            )}
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
}
