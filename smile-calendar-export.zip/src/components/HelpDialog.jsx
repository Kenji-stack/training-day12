// src/components/HelpDialog.jsx
import React, { useState } from 'react';

/**
 * ヘルプダイアログコンポーネント
 * IEC 62366-1準拠: コンテキスト依存のユーザーガイダンス
 * FMEA対応: 進捗誤解釈（RPN=70）の軽減
 */
export default function HelpDialog({ isOpen, onClose, topic = 'general' }) {
    const [activeTab, setActiveTab] = useState(topic);

    if (!isOpen) return null;

    const helpContent = {
        general: {
            title: 'Smile Calendarの使い方',
            icon: '📘',
            content: [
                {
                    question: 'このアプリは何をするものですか？',
                    answer: '毎日の口腔ケア（歯みがき、フロス、マウスウォッシュ）を記録し、習慣化をサポートします。'
                },
                {
                    question: 'どのように記録しますか？',
                    answer: 'カレンダーから日付を選択し、実施した項目のチェックボックスをオンにして「保存」ボタンをクリックします。'
                },
                {
                    question: 'データはどこに保存されますか？',
                    answer: 'Google Firestoreに安全に保存されます。同じGoogleアカウントでログインすれば、どのデバイスからでもアクセスできます。'
                }
            ]
        },
        progress: {
            title: '進捗の見方',
            icon: '📊',
            content: [
                {
                    question: '達成度（%）はどう計算されますか？',
                    answer: '今月の記録日数 ÷ 今日の日付 × 100% で計算されます。例: 11月27日時点で20日記録 = 20/27 ≈ 74%'
                },
                {
                    question: '連続記録とは何ですか？',
                    answer: '毎日続けて記録した日数です。1日でも記録しないとリセットされます。'
                },
                {
                    question: '次の目標までとは？',
                    answer: '次のマイルストーン（5日刻み）まであと何日かを示しています。例: 現在3日連続 → 次の目標5日まであと2日'
                }
            ]
        },
        record: {
            title: '記録の管理',
            icon: '📝',
            content: [
                {
                    question: '過去の記録を修正できますか？',
                    answer: 'はい。カレンダーから過去の日付を選択し、チェックボックスを変更して「保存」をクリックすれば上書きされます。'
                },
                {
                    question: '削除した記録は復元できますか？',
                    answer: 'いいえ、削除した記録は復元できません。削除前に必ず確認ダイアログの内容を読んでください。'
                },
                {
                    question: 'メモは必須ですか？',
                    answer: 'いいえ、メモは任意です。時間や気になったことを記録したい場合にご利用ください。'
                }
            ]
        },
        troubleshooting: {
            title: 'トラブルシューティング',
            icon: '🔧',
            content: [
                {
                    question: '「保存がタイムアウトしました」と表示されます',
                    answer: 'インターネット接続が不安定な可能性があります。Wi-Fiに接続するか、接続状況が良い場所に移動してください。'
                },
                {
                    question: '保存ボタンを押しても反応しません',
                    answer: 'ログインしているか確認してください。ログアウトしている場合は、画面右上の「ログアウト」ボタンからログインし直してください。'
                },
                {
                    question: '記録が表示されません',
                    answer: 'ブラウザをリロード（F5キー）してください。それでも表示されない場合は、正しい日付とGoogleアカウントでログインしているか確認してください。'
                }
            ]
        }
    };

    const currentContent = helpContent[activeTab] || helpContent.general;

    return (
        <>
            {/* Backdrop */}
            <div
                className="fixed inset-0 bg-black bg-opacity-50 z-40"
                onClick={onClose}
                aria-hidden="true"
            />

            {/* Dialog */}
            <div
                className="fixed inset-0 flex items-center justify-center z-50 p-4"
                role="dialog"
                aria-modal="true"
                aria-labelledby="help-dialog-title"
            >
                <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full max-h-[80vh] overflow-hidden flex flex-col">
                    {/* Header */}
                    <div className="bg-blue-500 text-white p-4 flex items-center justify-between">
                        <div className="flex items-center gap-3">
                            <span className="text-3xl" aria-hidden="true">❓</span>
                            <h2 id="help-dialog-title" className="text-xl font-bold">
                                ヘルプ
                            </h2>
                        </div>
                        <button
                            onClick={onClose}
                            className="text-white hover:bg-blue-600 rounded p-2 transition-colors"
                            aria-label="ヘルプを閉じる"
                        >
                            ✕
                        </button>
                    </div>

                    {/* Tabs */}
                    <div className="flex border-b border-gray-200 bg-gray-50">
                        {Object.keys(helpContent).map((key) => (
                            <button
                                key={key}
                                onClick={() => setActiveTab(key)}
                                className={`flex-1 px-4 py-3 text-sm font-medium transition-colors ${activeTab === key
                                        ? 'bg-white border-b-2 border-blue-500 text-blue-600'
                                        : 'text-gray-600 hover:text-gray-800 hover:bg-gray-100'
                                    }`}
                            >
                                <span className="mr-1" aria-hidden="true">{helpContent[key].icon}</span>
                                {helpContent[key].title}
                            </button>
                        ))}
                    </div>

                    {/* Content */}
                    <div className="flex-1 overflow-y-auto p-6">
                        <div className="space-y-4">
                            {currentContent.content.map((item, index) => (
                                <div key={index} className="border-l-4 border-blue-300 pl-4 py-2">
                                    <h3 className="font-bold text-gray-800 mb-1">
                                        Q: {item.question}
                                    </h3>
                                    <p className="text-gray-600 text-sm">
                                        A: {item.answer}
                                    </p>
                                </div>
                            ))}
                        </div>
                    </div>

                    {/* Footer */}
                    <div className="border-t border-gray-200 p-4 bg-gray-50 text-center">
                        <p className="text-sm text-gray-600">
                            さらに詳しい情報は
                            <a href="#" className="text-blue-600 hover:underline ml-1">
                                ユーザーマニュアル
                            </a>
                            をご覧ください。
                        </p>
                    </div>
                </div>
            </div>
        </>
    );
}
