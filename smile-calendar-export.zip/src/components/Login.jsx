import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { auth } from "../firebase";
import { GoogleAuthProvider, signInWithPopup } from "firebase/auth";
import "../styles/login.css";

export default function Login() {
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleGoogleLogin = async () => {
    setError("");
    try {
      const provider = new GoogleAuthProvider();
      await signInWithPopup(auth, provider);
      navigate("/");
    } catch (e) {
      console.error("Google login failed", e);
      setError("ログインに失敗しました。再度お試しください。");
    }
  };

  const handleEmailLogin = () => {
    // Placeholder for email login
    console.log("Email login clicked");
    // You might want to navigate to a different page or show a modal here
    // navigate("/login/email"); 
  };

  return (
    <div className="login-container">
      {/* Background Bubbles */}
      <div className="bubbles">
        <div className="bubble"></div>
        <div className="bubble"></div>
        <div className="bubble"></div>
        <div className="bubble"></div>
        <div className="bubble"></div>
        <div className="bubble"></div>
        <div className="bubble"></div>
        <div className="bubble"></div>
        <div className="bubble"></div>
        <div className="bubble"></div>
      </div>

      <div className="login-card" role="main" aria-labelledby="login-title">
        <div className="login-header">
          <div className="logo-icon">🦷</div>
          <h1 id="login-title" className="app-title">Smile Calendar</h1>
          <p className="app-subtitle">Build a brighter smile, brush by brush.</p>
        </div>

        <div className="login-actions">
          <button className="btn btn-google" onClick={handleGoogleLogin}>
            <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" alt="Google" className="google-icon" />
            <span>Sign in with Google</span>
          </button>

          <button className="btn btn-email" onClick={handleEmailLogin}>
            <span>Sign in with Email</span>
          </button>
        </div>

        {error && (
          <div
            className="error-message"
            role="alert"
            aria-live="assertive"
          >
            {error}
          </div>
        )}
      </div>

      <div className="login-footer-decoration">
        <div className="star-icon">✦</div>
      </div>
    </div>
  );
}
