// src/components/DayRecord.jsx
import React, { useEffect, useState } from 'react'
import { doc, setDoc, deleteDoc } from "firebase/firestore"
import { db } from "../firebase"
import { useAuth } from "../context/AuthContext"
import ErrorMessage from "./ErrorMessage"
import ConfirmDialog from "./ConfirmDialog"
import { getNetworkErrorMessage, getSuccessMessage } from "../utils/errorMessages"

export default function DayRecord({ dateKey, record, onSave }) {
  const { currentUser } = useAuth()

  const [form, setForm] = useState({
    brushingMorning: false,
    brushingNoon: false,
    brushingNight: false,
    mouthwash: false,
    floss: false,
    memo: ''
  })
  const [loading, setLoading] = useState(false)
  const [feedback, setFeedback] = useState({ type: '', message: '', details: '', action: '' })
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false)

  // Firestore の record を UI に反映
  useEffect(() => {
    if (record) {
      setForm({
        brushingMorning: !!record.brushingMorning,
        brushingNoon: !!record.brushingNoon,
        brushingNight: !!record.brushingNight,
        mouthwash: !!record.mouthwash,
        floss: !!record.floss,
        memo: record.memo || ''
      })
    } else {
      setForm({
        brushingMorning: false,
        brushingNoon: false,
        brushingNight: false,
        mouthwash: false,
        floss: false,
        memo: ''
      })
    }
    setFeedback({ type: '', message: '', details: '', action: '' })
  }, [dateKey, record]);

  // 安全策: データ更新を検知したら強制的にloadingを解除
  useEffect(() => {
    if (loading) {
      console.log("データ更新を検知: loadingを解除します")
      setLoading(false)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [record])

  // フィードバックメッセージを3秒後に自動的に消す
  useEffect(() => {
    if (feedback.message) {
      const timer = setTimeout(() => {
        setFeedback({ type: '', message: '', details: '', action: '' })
      }, 3000)
      return () => clearTimeout(timer)
    }
  }, [feedback])

  // Firestoreへ保存
  const save = async () => {
    if (!currentUser) {
      setFeedback({
        type: 'error',
        message: 'ログインが必要です',
        details: '画面右上からログインしてください。',
        action: ''
      })
      return
    }

    console.log("保存処理開始")
    setLoading(true)
    setFeedback({ type: '', message: '', details: '', action: '' })

    try {
      const ref = doc(db, "oralCareRecords", dateKey)

      const timeoutPromise = new Promise((_, reject) =>
        setTimeout(() => {
          const error = new Error("timeout")
          error.code = 'timeout'
          reject(error)
        }, 15000)
      );

      await Promise.race([
        setDoc(ref, {
          ...form,
          uid: currentUser.uid,
          updatedAt: new Date()
        }),
        timeoutPromise
      ]);

      console.log("保存完了:", dateKey)
      const successMsg = getSuccessMessage('save')
      setFeedback({
        type: successMsg.type,
        message: successMsg.message,
        details: successMsg.details
      })

      if (onSave) {
        onSave();
      }
    } catch (err) {
      console.error("保存エラー:", err)
      const errorMsg = getNetworkErrorMessage(err.code || 'default')
      setFeedback({
        type: 'error',
        message: errorMsg.message,
        details: errorMsg.details,
        action: errorMsg.action
      })
    } finally {
      setLoading(false)
    }
  }

  // 削除ボタンクリック
  const handleDeleteClick = () => {
    if (!currentUser) {
      setFeedback({
        type: 'error',
        message: 'ログインが必要です',
        details: '画面右上からログインしてください。'
      })
      return
    }
    setShowDeleteConfirm(true)
  }

  // 削除実行
  const confirmDelete = async () => {
    setShowDeleteConfirm(false)
    setLoading(true)
    setFeedback({ type: '', message: '', details: '', action: '' })

    try {
      const ref = doc(db, "oralCareRecords", dateKey)

      console.log("削除開始:", dateKey)
      await deleteDoc(ref)
      console.log("削除完了:", dateKey)

      const successMsg = getSuccessMessage('delete')
      setFeedback({
        type: successMsg.type,
        message: successMsg.message,
        details: successMsg.details
      })

      if (onSave) {
        onSave();
      }
    } catch (err) {
      console.error("削除エラー:", err)
      const errorMsg = getNetworkErrorMessage(err.code || 'default')
      setFeedback({
        type: 'error',
        message: errorMsg.message,
        details: errorMsg.details
      })
    } finally {
      setLoading(false)
    }
  }

  const ToggleItem = ({ label, icon, checked, onChange }) => (
    <div className="flex items-center mr-3 mb-1">
      <label className="switch">
        <input
          type="checkbox"
          checked={checked}
          onChange={onChange}
          aria-label={label}
        />
        <span className="slider round"></span>
      </label>
      <span className="text-gray-700 flex items-center text-sm font-medium">
        <span className="mr-1" aria-hidden="true">{icon}</span>
        {label}
      </span>
    </div>
  );

  return (
    <div className="bg-white rounded-xl shadow-sm p-3 mt-2">
      <h2
        id="record-title"
        className="text-base font-bold text-gray-800 mb-2 flex items-center space-x-2"
      >
        <span aria-hidden="true">📝</span>
        <span>今日の記録: {dateKey}</span>
      </h2>

      {/* フィードバックメッセージ */}
      {feedback.message && (
        <ErrorMessage
          type={feedback.type}
          message={feedback.message}
          details={feedback.details}
          action={feedback.action}
          onAction={() => { /* 再試行機能は将来実装 */ }}
          onDismiss={() => setFeedback({ type: '', message: '', details: '', action: '' })}
        />
      )}

      <form aria-labelledby="record-title" className="flex-1">
        {/* チェックボックス - 縦並び (Toggle Style) */}
        <div className="flex flex-col gap-y-2 mb-3">
          <ToggleItem
            label="朝の歯みがき"
            icon="🌅"
            checked={form.brushingMorning}
            onChange={(e) => setForm({ ...form, brushingMorning: e.target.checked })}
          />
          <ToggleItem
            label="昼の歯みがき"
            icon="☀️"
            checked={form.brushingNoon}
            onChange={(e) => setForm({ ...form, brushingNoon: e.target.checked })}
          />
          <ToggleItem
            label="夜の歯みがき"
            icon="🌙"
            checked={form.brushingNight}
            onChange={(e) => setForm({ ...form, brushingNight: e.target.checked })}
          />
          <ToggleItem
            label="マウスウォッシュ"
            icon="💧"
            checked={form.mouthwash}
            onChange={(e) => setForm({ ...form, mouthwash: e.target.checked })}
          />
          <ToggleItem
            label="フロス"
            icon="🦷"
            checked={form.floss}
            onChange={(e) => setForm({ ...form, floss: e.target.checked })}
          />
        </div>

        {/* メモ */}
        <div className="mb-3 relative">
          <label htmlFor="memo-input" className="block text-xs font-bold text-gray-500 mb-1 absolute -top-2.5 left-2 bg-white px-1">
            メモ
          </label>
          <textarea
            id="memo-input"
            className="w-full border border-gray-300 rounded-lg p-2 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm"
            rows={2}
            value={form.memo}
            onChange={(e) =>
              setForm({ ...form, memo: e.target.value })
            }
            placeholder="時間や気になったこと"
            aria-describedby="memo-description"
          />
        </div>

        {/* Action Buttons - Round Style */}
        <div className="flex gap-4 items-center mt-6">
          <button
            onClick={(e) => { e.preventDefault(); save(); }}
            disabled={loading}
            className="bg-green-500 hover:bg-green-600 text-white font-bold shadow-md disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 flex flex-col items-center justify-center text-xs"
            style={{ width: '64px', height: '64px', borderRadius: '50%' }}
            aria-label="記録を保存"
          >
            <span>保存</span>
          </button>

          <button
            onClick={(e) => { e.preventDefault(); handleDeleteClick(); }}
            disabled={loading}
            className="bg-gray-200 hover:bg-gray-300 text-gray-700 font-bold shadow-md disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 flex flex-col items-center justify-center text-xs"
            style={{ width: '64px', height: '64px', borderRadius: '50%' }}
            aria-label="記録を削除"
          >
            <span>削除</span>
          </button>
        </div>
      </form>

      {/* 削除確認ダイアログ */}
      <ConfirmDialog
        isOpen={showDeleteConfirm}
        title="記録の削除"
        message={`${dateKey} の記録を削除しますか？`}
        details="この操作は取り消せません。記録されたデータ（歯みがき、フロス、メモ）はすべて失われます。本当に削除してもよろしいですか？"
        confirmText="削除する"
        cancelText="キャンセル"
        severity="danger"
        onConfirm={confirmDelete}
        onCancel={() => setShowDeleteConfirm(false)}
      />
    </div>
  )
}
