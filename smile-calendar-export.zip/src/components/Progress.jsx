import React, { useMemo } from 'react';

export default function Progress({ recordsByDate, currentDate }) {
  const stats = useMemo(() => {
    const today = new Date();
    const currentYear = today.getFullYear();
    const currentMonth = today.getMonth();

    // 1. Calculate Monthly Achievement
    const todayDate = today.getDate();

    // Count days with records in the current month
    let recordedDaysCount = 0;
    if (recordsByDate) {
      Object.keys(recordsByDate).forEach(dateStr => {
        const date = new Date(dateStr);
        if (date.getFullYear() === currentYear && date.getMonth() === currentMonth) {
          const record = recordsByDate[dateStr];
          const hasData = record.brushingMorning || record.brushingNoon || record.brushingNight ||
            record.mouthwash || record.floss || (record.memo && record.memo.trim() !== "");
          if (hasData) {
            recordedDaysCount++;
          }
        }
      });
    }

    const achievement = Math.round((recordedDaysCount / todayDate) * 100) || 0;

    // 2. Calculate Consecutive Streak
    let streak = 0;
    let checkDate = new Date(today);
    const todayKey = `${currentYear}-${String(currentMonth + 1).padStart(2, '0')}-${String(todayDate).padStart(2, '0')}`;
    const hasTodayRecord = recordsByDate && recordsByDate[todayKey];

    if (!hasTodayRecord) {
      checkDate.setDate(checkDate.getDate() - 1);
    }

    while (true) {
      const year = checkDate.getFullYear();
      const month = String(checkDate.getMonth() + 1).padStart(2, '0');
      const day = String(checkDate.getDate()).padStart(2, '0');
      const key = `${year}-${month}-${day}`;

      if (recordsByDate && recordsByDate[key]) {
        const record = recordsByDate[key];
        const hasData = record.brushingMorning || record.brushingNoon || record.brushingNight ||
          record.mouthwash || record.floss || (record.memo && record.memo.trim() !== "");
        if (hasData) {
          streak++;
          checkDate.setDate(checkDate.getDate() - 1);
        } else {
          break;
        }
      } else {
        break;
      }
    }

    // 3. Next Goal
    const nextGoal = (Math.floor(streak / 5) + 1) * 5;
    const daysToGoal = nextGoal - streak;

    return { achievement, streak, nextGoal, daysToGoal };
  }, [recordsByDate]);

  // Circular Progress Calculation
  const radius = 50;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (stats.achievement / 100) * circumference;

  return (
    <div className="bg-white rounded-xl shadow-md p-4 flex flex-col items-center justify-center">
      <h2 className="text-sm font-semibold text-gray-700 mb-3 self-start">進捗</h2>

      <div className="relative mb-4" style={{ width: '80px', height: '80px' }}>
        {/* Background Circle */}
        <svg className="w-full h-full transform -rotate-90" viewBox="0 0 120 120">
          <circle
            cx="60"
            cy="60"
            r={radius}
            fill="none"
            stroke="#e5e7eb"
            strokeWidth="10"
          />
          {/* Progress Circle */}
          <circle
            cx="60"
            cy="60"
            r={radius}
            fill="none"
            stroke="#22c55e"
            strokeWidth="10"
            strokeDasharray={circumference}
            strokeDashoffset={strokeDashoffset}
            strokeLinecap="round"
            className="transition-all duration-1000 ease-out"
          />
        </svg>
      </div>

      <div className="w-full space-y-2">
        <div className="flex items-center justify-between text-xs">
          <span className="flex items-center text-gray-500">
            <span className="mr-1">☀️</span> 連続記録目標
          </span>
          <span className="font-semibold text-gray-800">{stats.nextGoal}日</span>
        </div>

        <div className="flex items-center justify-between text-xs">
          <span className="flex items-center text-gray-500">
            <span className="mr-1">🦷</span> 次の目標まで
          </span>
          <span className="font-semibold text-gray-800">{stats.daysToGoal}日</span>
        </div>
      </div>
    </div>
  );
}
