export const SAVE_MODE = "firebase";
