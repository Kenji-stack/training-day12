import { collection, query, where, getDocs } from "firebase/firestore";
import { db, auth } from "../firebase";

/**
 * ログインユーザーの全ての口腔ケア記録を取得する
 * @returns {Promise<Object>} 日付をキーとした記録オブジェクト { "2023-10-01": { ... }, ... }
 */
export async function getOralCareRecords() {
    const user = auth.currentUser;
    if (!user) return {};

    try {
        const q = query(
            collection(db, "oralCareRecords"),
            where("uid", "==", user.uid)
        );

        const querySnapshot = await getDocs(q);
        const records = {};

        querySnapshot.forEach((doc) => {
            // ドキュメントIDが日付 (YYYY-MM-DD) になっている前提
            records[doc.id] = doc.data();
        });

        return records;
    } catch (error) {
        console.error("Error fetching oral care records:", error);
        return {};
    }
}
