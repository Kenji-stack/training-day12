// src/utils/errorMessages.js

/**
 * エラーメッセージのヘルパー関数
 * IEC 62366-1準拠: ユーザーが理解しやすく、行動を促すメッセージ
 */

export const getNetworkErrorMessage = (errorCode) => {
    const messages = {
        'unavailable': {
            message: 'ネットワーク接続を確認してください',
            details: 'インターネット接続が不安定なため、データを保存できませんでした。Wi-Fiまたはモバイルデータ通信が有効か確認してください。',
            action: '再試行'
        },
        'permission-denied': {
            message: 'データ保存の権限がありません',
            details: 'ログインセッションが期限切れの可能性があります。再度ログインしてください。',
            action: 'ログイン画面へ'
        },
        'timeout': {
            message: '保存がタイムアウトしました',
            details: 'ネットワークの応答が遅いため、保存に時間がかかりすぎています。接続状況が良い場所に移動するか、時間をおいて再試行してください。',
            action: '再試行'
        },
        'default': {
            message: 'データの保存に失敗しました',
            details: '予期しないエラーが発生しました。ブラウザを再読み込みしてから再試行してください。',
            action: '再試行'
        }
    };

    return messages[errorCode] || messages.default;
};

export const getAuthErrorMessage = (errorCode) => {
    const messages = {
        'popup-blocked': {
            message: 'ログインウィンドウがブロックされました',
            details: 'ブラウザのポップアップブロッカーを無効にしてから、再度ログインしてください。',
            action: '再試行'
        },
        'popup-closed': {
            message: 'ログインがキャンセルされました',
            details: 'ログインウィンドウが閉じられました。もう一度お試しください。',
            action: '再試行'
        },
        'network-request-failed': {
            message: 'ネットワークエラーが発生しました',
            details: 'インターネット接続を確認してください。',
            action: '再試行'
        },
        'default': {
            message: 'ログインに失敗しました',
            details: 'もう一度お試しいただくか、しばらく時間をおいてから再試行してください。',
            action: '再試行'
        }
    };

    return messages[errorCode] || messages.default;
};

export const getDeleteConfirmMessage = (dateKey, hasData) => {
    if (!hasData) {
        return {
            message: 'この日付にはデータがありません',
            details: '削除する記録がありません。',
            severity: 'info'
        };
    }

    return {
        message: `${dateKey} の記録を削除しますか？`,
        details: 'この操作は取り消せません。記録されたデータ（歯みがき、フロス、メモ）はすべて失われます。本当に削除してもよろしいですか？',
        severity: 'danger'
    };
};

export const getSuccessMessage = (action) => {
    const messages = {
        save: {
            message: '保存しました',
            details: 'データが正常に保存されました。',
            type: 'success'
        },
        delete: {
            message: '削除しました',
            details: '記録が削除されました。',
            type: 'success'
        },
        login: {
            message: 'ログインしました',
            details: 'Smile Calendarへようこそ！',
            type: 'success'
        }
    };

    return messages[action] || { message: '完了しました', type: 'success' };
};
