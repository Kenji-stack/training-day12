// src/utils/logger.js

/**
 * ロガーユーティリティ
 * IEC 62366-1準拠: ユーザー操作とエラーの監査証跡
 */

const LOG_LEVEL = {
    DEBUG: 'DEBUG',
    INFO: 'INFO',
    WARNING: 'WARNING',
    ERROR: 'ERROR'
};

class Logger {
    constructor() {
        this.enabled = process.env.NODE_ENV === 'development' || true; // 本番でも有効
        this.logs = [];
        this.maxLogs = 100; // メモリ制限のため最大100件
    }

    /**
     * ユーザー操作をログ記録
     * @param {string} action - アクション名
     * @param {object} data - 追加データ
     */
    logUserAction(action, data = {}) {
        const logEntry = {
            level: LOG_LEVEL.INFO,
            type: 'USER_ACTION',
            action,
            data,
            timestamp: new Date().toISOString(),
            userAgent: navigator.userAgent
        };

        this._writeLog(logEntry);
    }

    /**
     * エラーをログ記録
     * @param {string} errorType - エラータイプ
     * @param {object} errorData - エラー詳細
     */
    logError(errorType, errorData = {}) {
        const logEntry = {
            level: LOG_LEVEL.ERROR,
            type: 'ERROR',
            errorType,
            data: errorData,
            timestamp: new Date().toISOString(),
            userAgent: navigator.userAgent,
            url: window.location.href
        };

        this._writeLog(logEntry);
        console.error('[Logger]', logEntry);
    }

    /**
     * パフォーマンスをログ記録
     * @param {string} metric - メトリック名
     * @param {number} duration - 実行時間（ミリ秒）
     */
    logPerformance(metric, duration) {
        const logEntry = {
            level: LOG_LEVEL.INFO,
            type: 'PERFORMANCE',
            metric,
            duration,
            timestamp: new Date().toISOString()
        };

        this._writeLog(logEntry);

        // パフォーマンス警告（5秒以上）
        if (duration > 5000) {
            console.warn(`[Logger] Performance warning: ${metric} took ${duration}ms`);
        }
    }

    /**
     * 警告をログ記録
     * @param {string} warning - 警告メッセージ
     * @param {object} data - 追加データ
     */
    logWarning(warning, data = {}) {
        const logEntry = {
            level: LOG_LEVEL.WARNING,
            type: 'WARNING',
            warning,
            data,
            timestamp: new Date().toISOString()
        };

        this._writeLog(logEntry);
        console.warn('[Logger]', logEntry);
    }

    /**
     * ログを内部配列に書き込み
     * @private
     */
    _writeLog(logEntry) {
        if (!this.enabled) return;

        this.logs.push(logEntry);

        // メモリ制限のため古いログを削除
        if (this.logs.length > this.maxLogs) {
            this.logs.shift();
        }

        // 開発環境ではコンソールにも出力
        if (process.env.NODE_ENV === 'development') {
            console.log('[Logger]', logEntry);
        }
    }

    /**
     * すべてのログを取得
     * @returns {Array} ログエントリの配列
     */
    getLogs() {
        return [...this.logs];
    }

    /**
     * エラーログのみを取得
     * @returns {Array} エラーログの配列
     */
    getErrors() {
        return this.logs.filter(log => log.level === LOG_LEVEL.ERROR);
    }

    /**
     * ログをクリア
     */
    clearLogs() {
        this.logs = [];
    }

    /**
     * ログをJSON文字列としてエクスポート
     * @returns {string} JSON形式のログ
     */
    exportLogs() {
        return JSON.stringify(this.logs, null, 2);
    }

    /**
     * ログをダウンロード（トラブルシューティング用）
     */
    downloadLogs() {
        const dataStr = this.exportLogs();
        const dataBlob = new Blob([dataStr], { type: 'application/json' });
        const url = URL.createObjectURL(dataBlob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `smile-calendar-logs-${new Date().toISOString()}.json`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
    }
}

// シングルトンインスタンス
const logger = new Logger();

export default logger;
