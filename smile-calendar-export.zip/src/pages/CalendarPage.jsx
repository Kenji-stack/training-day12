// src/pages/CalendarPage.jsx
import React, { useState, useEffect, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import DayRecord from "../components/DayRecord";
import CalendarUI from "../components/CalendarUI";
import Progress from "../components/Progress";
import { getRecord } from "../firebase/reservationApi";
import { getOralCareRecords } from "../firebase/oralCareApi";

export default function CalendarPage() {
  const navigate = useNavigate();
  const { currentUser } = useAuth();

  const [selectedDate, setSelectedDate] = useState(() => {
    const today = new Date();
    return today.toISOString().split("T")[0];
  });
  const [record, setRecord] = useState(null);
  const [recordsByDate, setRecordsByDate] = useState({});

  const fetchAllRecords = useCallback(async () => {
    if (currentUser) {
      const allRecords = await getOralCareRecords();
      setRecordsByDate(allRecords);
    }
  }, [currentUser]);

  useEffect(() => {
    fetchAllRecords();
  }, [fetchAllRecords]);

  useEffect(() => {
    if (selectedDate && recordsByDate) {
      setRecord(recordsByDate[selectedDate] || null);
    }
  }, [selectedDate, recordsByDate]);

  const handleDateClick = (dateString) => {
    setSelectedDate(dateString);
  };

  const handleLogout = () => {
    navigate("/logout");
  };

  return (
    <div
      style={{
        padding: "12px 20px",
        maxWidth: "1400px",
        margin: "0 auto",
        minHeight: "100vh",
        backgroundImage: `url(${process.env.PUBLIC_URL}/images/tooth-bacteria.png)`,
        backgroundRepeat: "no-repeat",
        backgroundPosition: "center center",
        backgroundSize: "20%",
        backgroundAttachment: "fixed",
        opacity: 0.98,
        overflowY: "auto",
      }}
    >
      <header
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          width: "100%",
          marginBottom: "12px",
        }}
      >
        <h1 className="text-2xl font-bold text-gray-800">Smile Calendar</h1>
        <button
          onClick={handleLogout}
          className="bg-gray-100 hover:bg-gray-200 text-gray-800 font-medium py-2 px-4 rounded text-sm"
        >
          ログアウト
        </button>
      </header>

      <div className="flex flex-col gap-4">
        <div className="bg-white rounded-xl shadow-sm p-4">
          <CalendarUI onSelectDate={handleDateClick} recordsByDate={recordsByDate} />
        </div>

        {selectedDate && (
          <div className="flex flex-col md:flex-row gap-4 items-start">
            <div className="flex-1 w-full">
              <DayRecord dateKey={selectedDate} record={record} onSave={fetchAllRecords} />
            </div>
            <div className="w-full md:w-64 shrink-0">
              <Progress recordsByDate={recordsByDate} currentDate={selectedDate} />
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
